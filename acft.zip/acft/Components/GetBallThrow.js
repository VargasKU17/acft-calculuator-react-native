import GetScoresWithDecimal from './GetScoresWithDecimal'
import BallThrowScores from './BallThrowScores'

const GetBallThrowScores = GetScoresWithDecimal(BallThrowScores)
export default GetBallThrowScores