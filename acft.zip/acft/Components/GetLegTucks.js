import GetScores from './GetScores'
import LegTuckScores from './LegTuckScores'

const GetLegTuckScores = GetScores(LegTuckScores)
export default GetLegTuckScores