const LegTuckScores = [
    {points: 100, raw: 20},
    {points: 98, raw: 19},
    {points: 96, raw: 18},
    {points: 94, raw: 17},
    {points: 92, raw: 16},
    {points: 90, raw: 15},
    {points: 88, raw: 14},
    {points: 86, raw: 13},
    {points: 84, raw: 12},
    {points: 82, raw: 11},
    {points: 80, raw: 10},
    {points: 78, raw: 9},
    {points: 76, raw: 8},
    {points: 74, raw: 7},
    {points: 72, raw: 6},
    {points: 70, raw: 5},
    {points: 68, raw: 4},
    {points: 65, raw: 3},
    {points: 62, raw: 2},
    {points: 60, raw: 1},
    {points: 0, raw: 0},

]

export default LegTuckScores