import GetTimedScores from './GetTimedScores'
import TwoMileScores from './TwoMileScores'

const GetTwoMileScores = GetTimedScores(TwoMileScores)
export default GetTwoMileScores