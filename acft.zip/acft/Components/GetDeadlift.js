import GetScores from './GetScores'
import DeadliftScores from './DeadliftScores'

const GetDeadliftScores = GetScores(DeadliftScores)
export default GetDeadliftScores