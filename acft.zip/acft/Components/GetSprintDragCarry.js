import GetTimedScores from './GetTimedScores'
import SprintDragCarryScores from './SprintDragCarryScores'

const GetSprintDragCarryScores = GetTimedScores(SprintDragCarryScores)
export default GetSprintDragCarryScores