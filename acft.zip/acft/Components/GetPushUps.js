import GetScores from './GetScores'
import PushupScores from './PushupScores'

const GetPushupScores = GetScores(PushupScores)
export default GetPushupScores